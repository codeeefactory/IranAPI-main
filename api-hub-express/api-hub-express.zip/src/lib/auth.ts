const CSRF_COOKIE_NAME = "csrftoken";
const SESSION_COOKIE_NAME = "sessionid";


export function getCookie(name: string) {
  if (typeof document === "undefined") {
    return null;
  }

  const prefix = `${name}=`;
  return (
    document.cookie
      .split(";")
      .map((item) => item.trim())
      .find((item) => item.startsWith(prefix))
      ?.slice(prefix.length) || null
  );
}


export function getCsrfToken() {
  return getCookie(CSRF_COOKIE_NAME);
}


export function hasSessionCookie() {
  return Boolean(getCookie(SESSION_COOKIE_NAME));
}
