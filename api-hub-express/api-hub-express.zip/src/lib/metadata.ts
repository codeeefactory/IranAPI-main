import { useEffect } from "react";

import { DEFAULT_DESCRIPTION, DEFAULT_OG_IMAGE, DEFAULT_TITLE, SITE_NAME, toImageUrl, toSiteUrl } from "@/lib/site";

type StructuredData = Record<string, unknown> | Array<Record<string, unknown>>;

interface PageMetadataOptions {
  title?: string;
  description?: string;
  path?: string;
  noindex?: boolean;
  type?: "website" | "article";
  image?: string;
  structuredData?: StructuredData;
}

function upsertMeta(selector: string, attributes: Record<string, string>) {
  let element = document.head.querySelector<HTMLMetaElement>(selector);
  if (!element) {
    element = document.createElement("meta");
    document.head.appendChild(element);
  }

  Object.entries(attributes).forEach(([key, value]) => {
    element?.setAttribute(key, value);
  });
}

function upsertCanonical(href: string) {
  let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!link) {
    link = document.createElement("link");
    link.rel = "canonical";
    document.head.appendChild(link);
  }

  link.href = href;
}

function upsertStructuredData(data?: StructuredData) {
  const scriptId = "iranapi-structured-data";
  const existingScript = document.getElementById(scriptId);

  if (!data) {
    existingScript?.remove();
    return;
  }

  const script = existingScript || document.createElement("script");
  script.id = scriptId;
  script.setAttribute("type", "application/ld+json");
  script.textContent = JSON.stringify(data);

  if (!existingScript) {
    document.head.appendChild(script);
  }
}

export function usePageMetadata({
  title,
  description = DEFAULT_DESCRIPTION,
  path,
  noindex = false,
  type = "website",
  image = DEFAULT_OG_IMAGE,
  structuredData,
}: PageMetadataOptions) {
  useEffect(() => {
    const nextTitle = title ? `${title} | ${SITE_NAME}` : DEFAULT_TITLE;
    const nextUrl = toSiteUrl(path || `${window.location.pathname}${window.location.search}`);
    const nextImage = toImageUrl(image);

    document.title = nextTitle;
    document.documentElement.lang = "fa-IR";
    document.documentElement.dir = "rtl";

    upsertMeta('meta[name="description"]', { name: "description", content: description });
    upsertMeta('meta[name="robots"]', {
      name: "robots",
      content: noindex ? "noindex,nofollow" : "index,follow",
    });
    upsertMeta('meta[property="og:title"]', { property: "og:title", content: nextTitle });
    upsertMeta('meta[property="og:description"]', { property: "og:description", content: description });
    upsertMeta('meta[property="og:type"]', { property: "og:type", content: type });
    upsertMeta('meta[property="og:url"]', { property: "og:url", content: nextUrl });
    upsertMeta('meta[property="og:locale"]', { property: "og:locale", content: "fa_IR" });
    upsertMeta('meta[property="og:site_name"]', { property: "og:site_name", content: SITE_NAME });
    upsertMeta('meta[property="og:image"]', { property: "og:image", content: nextImage });
    upsertMeta('meta[name="twitter:card"]', { name: "twitter:card", content: "summary_large_image" });
    upsertMeta('meta[name="twitter:title"]', { name: "twitter:title", content: nextTitle });
    upsertMeta('meta[name="twitter:description"]', { name: "twitter:description", content: description });
    upsertMeta('meta[name="twitter:image"]', { name: "twitter:image", content: nextImage });
    upsertMeta('meta[name="application-name"]', { name: "application-name", content: SITE_NAME });
    upsertMeta('meta[name="apple-mobile-web-app-title"]', { name: "apple-mobile-web-app-title", content: SITE_NAME });
    upsertMeta('meta[name="theme-color"]', {
      name: "theme-color",
      content: document.documentElement.classList.contains("dark") ? "#0f172a" : "#f4f7fb",
    });
    upsertCanonical(nextUrl);
    upsertStructuredData(structuredData);
  }, [description, image, noindex, path, structuredData, title, type]);
}

export function createBreadcrumbSchema(items: Array<{ name: string; path: string }>) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: toSiteUrl(item.path),
    })),
  };
}
