import { describe, expect, it } from "vitest";

import { getCookie } from "@/lib/auth";


describe("auth cookie helpers", () => {
  it("reads a cookie value by name", () => {
    Object.defineProperty(document, "cookie", {
      value: "csrftoken=token123; sessionid=session456",
      configurable: true,
    });

    expect(getCookie("csrftoken")).toBe("token123");
    expect(getCookie("sessionid")).toBe("session456");
  });

  it("returns null when the cookie is absent", () => {
    Object.defineProperty(document, "cookie", {
      value: "theme=light",
      configurable: true,
    });

    expect(getCookie("csrftoken")).toBeNull();
  });
});
