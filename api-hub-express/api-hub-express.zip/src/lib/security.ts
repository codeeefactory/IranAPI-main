const SECRET_PATTERNS = [
  /iapi_[a-f0-9]{24,}/gi,
  /(bearer|token)\s+[a-z0-9._~+/=-]{12,}/gi,
  /(sessionid|csrftoken)=([^;\s]+)/gi,
];

export function redactClientSecret(value: unknown) {
  const text = value instanceof Error ? value.message : String(value ?? "");
  return SECRET_PATTERNS.reduce((current, pattern) => current.replace(pattern, "[redacted]"), text);
}
