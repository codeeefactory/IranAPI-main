export const SITE_NAME = "IranAPI";
export const SITE_TAGLINE = "هاب API برای تیم‌های ایرانی";
export const DEFAULT_TITLE = `${SITE_NAME} | ${SITE_TAGLINE}`;
export const DEFAULT_DESCRIPTION =
  "IranAPI یک هاب فارسی برای پیدا کردن، مقایسه و مدیریت APIها است؛ با مستندات روشن، پلن‌های قابل مقایسه و داشبوردی که تیم‌های فنی را سریع‌تر به اتصال می‌رساند.";
export const DEFAULT_OG_IMAGE = "/og-default.svg";

const FALLBACK_SITE_URL = (import.meta.env.VITE_SITE_URL as string | undefined)?.replace(/\/+$/, "") || "https://iranapi.local";

export function getSiteOrigin() {
  if (typeof window !== "undefined" && window.location.origin) {
    return window.location.origin;
  }

  return FALLBACK_SITE_URL;
}

export function toSiteUrl(path = "/") {
  return new URL(path, getSiteOrigin()).toString();
}

export function toImageUrl(path = DEFAULT_OG_IMAGE) {
  return new URL(path, getSiteOrigin()).toString();
}

export function formatFaNumber(value: number | string) {
  return Number(value || 0).toLocaleString("fa-IR");
}

export function formatCurrencyLabel(value: number | string | null | undefined, currency = "IRR") {
  if (value === null || value === undefined || value === "") {
    return "رایگان / نامشخص";
  }

  return `${formatFaNumber(Number(value))} ${currency}`;
}

export function formatDateTimeFa(value: string) {
  return new Date(value).toLocaleString("fa-IR");
}
