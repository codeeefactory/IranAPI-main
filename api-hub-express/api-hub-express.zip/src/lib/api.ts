import axios from "axios";

import { getCsrfToken } from "@/lib/auth";


export interface ApiErrorEnvelope {
  error: {
    code: string;
    message: string;
    details?: unknown;
    request_id?: string | null;
  };
}

export interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface RapidApiMetadata {
  canonical_version: string;
  listing_url: string;
  package_slug: string;
  public_auth_scheme: "rapidapi_proxy" | "api_key" | "bearer" | "oauth2" | "basic" | "none";
  support_url: string;
  publication_status: "draft" | "ready" | "published" | "deprecated";
}

export interface CategorySummary {
  id: number;
  name: string;
  name_en: string;
  slug: string;
  icon: string;
  color: string;
}

export interface Category extends CategorySummary {
  description: string;
  apis_count: number;
  created_at: string;
  updated_at: string;
}

export interface PricingPlan {
  id: number;
  api_slug: string;
  api_rapidapi_listing_url: string;
  name: string;
  plan_type: "free" | "basic" | "pro" | "enterprise";
  price: string;
  currency: string;
  requests_per_month: number | null;
  requests_per_day: number | null;
  features: string[];
  is_popular: boolean;
  is_active: boolean;
  rapidapi_plan_slug: string;
  is_listed_on_rapidapi: boolean;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  slug: string;
  description: string;
  plan_type: "starter" | "growth" | "scale" | string;
  price: string;
  currency: string;
  interval: "month" | "year" | string;
  interval_days: number;
  api_publish_limit: number | null;
  included_requests: number | null;
  features: string[];
  is_popular: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserSubscription {
  id: number;
  status: "active" | "canceled" | "expired" | string;
  plan: SubscriptionPlan;
  days_remaining?: number;
  starts_at: string;
  renews_at: string;
  ends_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionCheckout {
  id: number;
  status: "pending" | "paid" | "expired" | "canceled" | string;
  amount: string;
  currency: string;
  gateway: string;
  reference: string;
  plan: SubscriptionPlan;
  created_at: string;
  updated_at: string;
  expires_at: string;
  confirmed_at: string | null;
}

export interface Documentation {
  id: number;
  api_slug: string;
  title: string;
  slug: string;
  content: string;
  order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface APIEndpoint {
  id: number;
  api_slug: string;
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | string;
  path: string;
  name: string;
  summary: string;
  group: string;
  request_schema: Record<string, unknown>;
  response_schema: Record<string, unknown>;
  sample_request: Record<string, unknown>;
  sample_response: Record<string, unknown>;
  requires_auth: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface API {
  id: number;
  name: string;
  name_en: string;
  slug: string;
  short_description: string;
  description?: string;
  category: CategorySummary | null;
  logo: string;
  banner?: string;
  status: "active" | "inactive" | "beta" | "deprecated";
  is_featured: boolean;
  is_popular: boolean;
  rating: string;
  rating_count: number;
  views_count: number;
  tags: string[];
  pricing_from: string | null;
  base_url?: string;
  documentation_url?: string;
  pricing_plans?: PricingPlan[];
  documentations?: Documentation[];
  endpoints?: APIEndpoint[];
  created_by_username?: string | null;
  rapidapi: RapidApiMetadata;
  created_at: string;
  updated_at: string;
}

export type APISummary = API;

export interface APIReleaseInput {
  name: string;
  base_url: string;
  documentation_url?: string;
  auth_scheme: "api-key" | "api_key" | "bearer" | "oauth2" | "basic" | "none";
  category?: string;
  tags?: string[];
  description: string;
}

export interface APIReleaseResponse {
  message: string;
  api: API;
}

export interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  date_joined: string;
}

export interface UserProfile {
  id: number;
  user: User;
  phone: string;
  company: string;
  bio: string;
  avatar: string | null;
  api_key: string | null;
  api_key_preview?: string | null;
  has_api_key?: boolean;
  created_at: string;
  updated_at: string;
}

export interface SessionResponse {
  authenticated: boolean;
  user: User | null;
  profile: UserProfile | null;
}

export interface AuthResponse extends SessionResponse {
  message: string;
}

export interface APIKeyResponse {
  message: string;
  api_key: string | null;
  profile: UserProfile;
}

export interface SocialAuthProvider {
  slug: "google" | "github" | "microsoft" | "linkedin" | string;
  label: string;
  enabled: boolean;
  start_url: string;
}

export interface SocialAuthProvidersResponse {
  providers: SocialAuthProvider[];
}

export interface RatingResponse {
  message: string;
  created: boolean;
  rating: string;
  rating_count: number;
  your_rating: number;
}

export interface AccessGrant {
  id: number;
  api: APISummary;
  pricing_plan: PricingPlan | null;
  source: "iranapi" | "rapidapi" | "manual" | "legacy";
  status: "pending" | "active" | "paused" | "expired" | "canceled";
  external_subscription_id: string;
  starts_at: string | null;
  ends_at: string | null;
  requests_per_day: number | null;
  requests_per_month: number | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface UsageItem {
  id: number;
  api: APISummary;
  access_grant: AccessGrant | null;
  source: "imported" | "iranapi_sync" | "rapidapi_sync" | "manual";
  requests_count: number;
  last_used: string;
  window_started_at: string | null;
  window_ended_at: string | null;
  created_at: string;
}

export interface UsageStats {
  total_requests: number;
  active_apis: number;
  recent_usage_count: number;
  recent_requests: number;
  top_apis: Array<{
    name: string;
    slug: string;
    requests_count: number;
  }>;
}


const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/+$/, "") || "/api/v1";

const client = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: true,
  xsrfCookieName: "csrftoken",
  xsrfHeaderName: "X-CSRFToken",
});

let csrfBootstrapPromise: Promise<SessionResponse> | null = null;


async function ensureCsrfCookie() {
  if (getCsrfToken()) {
    return;
  }

  if (!csrfBootstrapPromise) {
    csrfBootstrapPromise = client
      .get<SessionResponse>("/auth/session/")
      .then((response) => response.data)
      .finally(() => {
        csrfBootstrapPromise = null;
      });
  }

  await csrfBootstrapPromise;
}


function paramsFromRecord(record: Record<string, string | number | boolean | undefined>) {
  const params = new URLSearchParams();
  Object.entries(record).forEach(([key, value]) => {
    if (value === undefined || value === "" || value === null) {
      return;
    }
    params.set(key, String(value));
  });
  return params;
}


export const apiService = {
  getSession() {
    return client.get<SessionResponse>("/auth/session/").then((response) => response.data);
  },

  getCategories(page?: number) {
    const params = paramsFromRecord({ page, page_size: 100 });
    return client.get<PaginatedResponse<Category>>("/catalog/categories/", { params }).then((response) => response.data);
  },

  getCategory(slug: string) {
    return client.get<Category>(`/catalog/categories/${slug}/`).then((response) => response.data);
  },

  getCategoryApis(slug: string, page?: number) {
    const params = paramsFromRecord({ page, page_size: 12 });
    return client.get<PaginatedResponse<APISummary>>(`/catalog/categories/${slug}/apis/`, { params }).then((response) => response.data);
  },

  getAPIs(params?: {
    search?: string;
    category?: string;
    featured?: boolean;
    popular?: boolean;
    owned?: boolean;
    ordering?: string;
    page?: number;
    page_size?: number;
    tag?: string;
  }) {
    const nextParams = { page_size: 12, ...params };
    return client.get<PaginatedResponse<APISummary>>("/catalog/apis/", { params: nextParams }).then((response) => response.data);
  },

  async releaseAPI(data: APIReleaseInput) {
    await ensureCsrfCookie();
    return client.post<APIReleaseResponse>("/catalog/apis/", data).then((response) => response.data);
  },

  getAPI(slug: string) {
    return client.get<API>(`/catalog/apis/${slug}/`).then((response) => response.data);
  },

  getSimilarAPIs(slug: string) {
    return client.get<APISummary[]>(`/catalog/apis/${slug}/similar/`).then((response) => response.data);
  },

  async rateAPI(slug: string, rating: number) {
    await ensureCsrfCookie();
    return client.post<RatingResponse>(`/catalog/apis/${slug}/ratings/`, { rating }).then((response) => response.data);
  },

  getPricingPlans(apiSlug?: string, page?: number) {
    const params = paramsFromRecord({ api: apiSlug, page, page_size: 100 });
    return client.get<PaginatedResponse<PricingPlan>>("/catalog/pricing-plans/", { params }).then((response) => response.data);
  },

  getSubscriptionPlans() {
    return client.get<PaginatedResponse<SubscriptionPlan>>("/catalog/subscription-plans/").then((response) => response.data);
  },

  getCurrentSubscription() {
    return client.get<{ subscription: UserSubscription | null }>("/account/subscription/").then((response) => response.data);
  },

  async subscribe(planId: number) {
    await ensureCsrfCookie();
    return client
      .post<{ message: string; checkout: SubscriptionCheckout }>("/account/subscription/", { plan_id: planId })
      .then((response) => response.data);
  },

  getSubscriptionCheckout(checkoutId: number) {
    return client
      .get<{ checkout: SubscriptionCheckout }>(`/account/subscription/checkout/${checkoutId}/`)
      .then((response) => response.data);
  },

  async confirmSubscriptionCheckout(checkoutId: number) {
    await ensureCsrfCookie();
    return client
      .post<{ message: string; checkout: SubscriptionCheckout; subscription: UserSubscription }>(
        `/account/subscription/checkout/${checkoutId}/confirm/`,
      )
      .then((response) => response.data);
  },

  async cancelSubscriptionCheckout(checkoutId: number) {
    await ensureCsrfCookie();
    return client
      .delete<{ message: string; checkout: SubscriptionCheckout }>(`/account/subscription/checkout/${checkoutId}/`)
      .then((response) => response.data);
  },

  getDocumentations(apiSlug?: string, page?: number) {
    const params = paramsFromRecord({ api: apiSlug, page, page_size: 100 });
    return client.get<PaginatedResponse<Documentation>>("/catalog/documentations/", { params }).then((response) => response.data);
  },

  async register(data: {
    username: string;
    email?: string;
    password: string;
    password_confirm: string;
    first_name?: string;
    last_name?: string;
  }) {
    await ensureCsrfCookie();
    return client.post<AuthResponse>("/auth/register/", data).then((response) => response.data);
  },

  async login(username: string, password: string) {
    await ensureCsrfCookie();
    return client.post<AuthResponse>("/auth/login/", { username, password }).then((response) => response.data);
  },

  getSocialAuthProviders() {
    return client.get<SocialAuthProvidersResponse>("/auth/social/providers/").then((response) => response.data);
  },

  async logout() {
    await ensureCsrfCookie();
    return client.post<{ message: string; authenticated: boolean }>("/auth/logout/").then((response) => response.data);
  },

  getCurrentUser() {
    return client.get<User>("/account/user/").then((response) => response.data);
  },

  async updateUser(data: Partial<Pick<User, "email" | "first_name" | "last_name">>) {
    await ensureCsrfCookie();
    return client.patch<{ message: string; user: User }>("/account/user/", data).then((response) => response.data);
  },

  getProfile() {
    return client.get<UserProfile>("/account/profile/").then((response) => response.data);
  },

  async updateProfile(data: Partial<Pick<UserProfile, "phone" | "company" | "bio" | "avatar">>) {
    await ensureCsrfCookie();
    return client.patch<{ message: string; profile: UserProfile }>("/account/profile/", data).then((response) => response.data);
  },

  async generateLegacyAPIKey() {
    await ensureCsrfCookie();
    return client.post<APIKeyResponse>("/account/legacy-api-key/").then((response) => response.data);
  },

  getAccessGrants() {
    return client.get<PaginatedResponse<AccessGrant>>("/account/access/").then((response) => response.data);
  },

  getUsage(page?: number) {
    const params = paramsFromRecord({ page, page_size: 25 });
    return client.get<PaginatedResponse<UsageItem>>("/account/usage/", { params }).then((response) => response.data);
  },

  getUsageStats() {
    return client.get<UsageStats>("/account/usage/stats/").then((response) => response.data);
  },

  getHealth() {
    return client.get<{ status: string; timestamp: string }>("/system/health/").then((response) => response.data);
  },
};


export function getErrorMessage(error: unknown, fallback = "خطایی رخ داد.") {
  if (axios.isAxiosError<ApiErrorEnvelope>(error)) {
    return error.response?.data?.error?.message || error.message || fallback;
  }

  if (error instanceof Error) {
    return error.message;
  }

  return fallback;
}
