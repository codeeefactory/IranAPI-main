import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from "react";

export type Locale = "fa" | "en" | "ar" | "es" | "fr" | "tr";

export const supportedLocales: Array<{
  code: Locale;
  nativeName: string;
  englishName: string;
  dir: "rtl" | "ltr";
  htmlLang: string;
}> = [
  { code: "fa", nativeName: "فارسی", englishName: "Persian", dir: "rtl", htmlLang: "fa-IR" },
  { code: "en", nativeName: "English", englishName: "English", dir: "ltr", htmlLang: "en" },
  { code: "ar", nativeName: "العربية", englishName: "Arabic", dir: "rtl", htmlLang: "ar" },
  { code: "es", nativeName: "Español", englishName: "Spanish", dir: "ltr", htmlLang: "es" },
  { code: "fr", nativeName: "Français", englishName: "French", dir: "ltr", htmlLang: "fr" },
  { code: "tr", nativeName: "Türkçe", englishName: "Turkish", dir: "ltr", htmlLang: "tr" },
];

const isLocale = (value: string | null): value is Locale => supportedLocales.some((locale) => locale.code === value);

const getLocaleMeta = (locale: Locale) => supportedLocales.find((item) => item.code === locale) || supportedLocales[0];

type TranslationKey =
  | "app.skip"
  | "app.loadingRoute"
  | "nav.home"
  | "nav.browse"
  | "nav.docs"
  | "nav.pricing"
  | "nav.studio"
  | "nav.caller"
  | "nav.consoleBadge"
  | "nav.tagline"
  | "nav.main"
  | "nav.mobile"
  | "nav.signIn"
  | "nav.signUp"
  | "nav.dashboard"
  | "nav.logout"
  | "nav.openMenu"
  | "nav.sheetDescription"
  | "nav.workspace"
  | "nav.language"
  | "footer.description"
  | "footer.quick"
  | "footer.trust"
  | "footer.terms"
  | "footer.privacy"
  | "studio.title"
  | "studio.metaDescription"
  | "studio.eyebrow"
  | "studio.subtitle"
  | "studio.addProject"
  | "studio.newProject"
  | "studio.projectName"
  | "studio.baseUrl"
  | "studio.docsUrl"
  | "studio.category"
  | "studio.tags"
  | "studio.description"
  | "studio.createPending"
  | "studio.createPublish"
  | "studio.search"
  | "studio.all"
  | "studio.favorites"
  | "studio.activeProjects"
  | "studio.emptyTitle"
  | "studio.emptyText"
  | "studio.demoProject"
  | "studio.demoDescription"
  | "studio.updatedToday"
  | "studio.checklist"
  | "studio.tabProjects"
  | "studio.tabRequests"
  | "studio.tabTests"
  | "studio.tabListing"
  | "studio.tabAnalytics"
  | "studio.tabInbox"
  | "studio.tabSettings"
  | "studio.requestsTitle"
  | "studio.testsTitle"
  | "studio.listingTitle"
  | "studio.analyticsTitle"
  | "studio.inboxTitle"
  | "studio.settingsTitle"
  | "studio.requestsCopy"
  | "studio.testsCopy"
  | "studio.listingCopy"
  | "studio.analyticsCopy"
  | "studio.inboxCopy"
  | "studio.settingsCopy"
  | "studio.runTest"
  | "studio.publish"
  | "studio.configure"
  | "rapid.dashboardTitle"
  | "rapid.dashboardCopy"
  | "rapid.overview"
  | "rapid.traffic"
  | "rapid.searchInsights"
  | "rapid.governance"
  | "rapid.billing"
  | "rapid.hub"
  | "rapid.orgModel"
  | "rapid.orgModelCopy";

const baseTranslations: Record<"fa" | "en" | "ar", Record<TranslationKey, string>> = {
  fa: {
    "app.skip": "پرش به محتوای اصلی",
    "app.loadingRoute": "در حال بارگذاری مسیر",
    "nav.home": "خانه",
    "nav.browse": "کشف APIها",
    "nav.docs": "مستندات",
    "nav.pricing": "قیمت‌گذاری",
    "nav.studio": "استودیو",
    "nav.caller": "فراخوان API",
    "nav.consoleBadge": "کنسول API",
    "nav.tagline": "کشف، مستندات و مدیریت API در یک کنسول فارسی",
    "nav.main": "ناوبری اصلی",
    "nav.mobile": "ناوبری موبایل",
    "nav.signIn": "ورود",
    "nav.signUp": "ساخت حساب",
    "nav.dashboard": "داشبورد",
    "nav.logout": "خروج",
    "nav.openMenu": "باز کردن منو",
    "nav.sheetDescription": "دسترسی سریع به کنسول، مستندات و حساب کاربری",
    "nav.workspace": "فضای کاری IranAPI",
    "nav.language": "زبان",
    "footer.description": "یک کنسول فارسی و انگلیسی برای کشف API، مقایسه پلن‌ها، خواندن مستندات و مدیریت دسترسی از ایده تا اتصال پایدار.",
    "footer.quick": "دسترسی سریع",
    "footer.trust": "اعتماد و سیاست‌ها",
    "footer.terms": "شرایط استفاده",
    "footer.privacy": "حریم خصوصی",
    "studio.title": "استودیو IranAPI",
    "studio.metaDescription": "ساخت و مدیریت پروژه‌های API.",
    "studio.eyebrow": "فضای کاری پروژه API",
    "studio.subtitle": "عملیات پروژه، آماده‌سازی صفحه هاب، تست درخواست، تحلیل مصرف و انتشار API در یک محیط.",
    "studio.addProject": "افزودن پروژه API",
    "studio.newProject": "پروژه API جدید",
    "studio.projectName": "نام پروژه",
    "studio.baseUrl": "آدرس پایه",
    "studio.docsUrl": "آدرس مستندات",
    "studio.category": "دسته‌بندی",
    "studio.tags": "برچسب‌ها: sms, webhook, ai",
    "studio.description": "توضیح کوتاه پروژه",
    "studio.createPending": "در حال ساخت...",
    "studio.createPublish": "ساخت و انتشار",
    "studio.search": "جستجوی پروژه‌های API",
    "studio.all": "همه",
    "studio.favorites": "علاقه‌مندی‌ها",
    "studio.activeProjects": "پروژه فعال",
    "studio.emptyTitle": "هنوز پروژه API ندارید",
    "studio.emptyText": "یک پروژه جدید بسازید یا با پروژه نمونه مسیر انتشار، مستندات، تست و همکاری را بررسی کنید.",
    "studio.demoProject": "پروژه نمونه",
    "studio.demoDescription": "پروژه نمونه با تنظیمات امن برای تجربه مسیر استودیو.",
    "studio.updatedToday": "به‌روزرسانی امروز",
    "studio.checklist": "چک‌لیست انتشار استودیو",
    "studio.tabProjects": "پروژه‌ها",
    "studio.tabRequests": "درخواست‌ها",
    "studio.tabTests": "تست‌ها",
    "studio.tabListing": "صفحه هاب",
    "studio.tabAnalytics": "تحلیل",
    "studio.tabInbox": "پیام‌ها",
    "studio.tabSettings": "تنظیمات",
    "studio.requestsTitle": "کنسول درخواست",
    "studio.testsTitle": "تست و مانیتورینگ",
    "studio.listingTitle": "آماده‌سازی صفحه هاب",
    "studio.analyticsTitle": "تحلیل مصرف",
    "studio.inboxTitle": "پیام‌ها و بحث‌ها",
    "studio.settingsTitle": "تنظیمات پروژه",
    "studio.requestsCopy": "با الهام از RapidAPI Client، مسیر، متد، هدر و نمونه بدنه را کنار پروژه IranAPI نگه دارید.",
    "studio.testsCopy": "سناریوهای سلامت، زمان پاسخ و وضعیت انتشار را قبل از نمایش عمومی اجرا کنید.",
    "studio.listingCopy": "عنوان، دسته، برچسب، مستندات، پلن و نمونه کد صفحه هاب را کامل کنید.",
    "studio.analyticsCopy": "بازدید، درخواست، کلید فعال و وضعیت پلن‌ها را در یک نمای عملیاتی ببینید.",
    "studio.inboxCopy": "بازخورد مصرف‌کننده، درخواست پشتیبانی و بحث‌های مستندات را پیگیری کنید.",
    "studio.settingsCopy": "احراز هویت، نسخه canonical، لینک پشتیبانی و وضعیت انتشار را کنترل کنید.",
    "studio.runTest": "اجرای تست",
    "studio.publish": "انتشار",
    "studio.configure": "تنظیم",
    "rapid.dashboardTitle": "IranAPI با تجربه الهام‌گرفته از RapidAPI Hub",
    "rapid.dashboardCopy": "نمای مدیریت ایرانAPI روی سه محور بازار API ساخته شده است: overview، تحلیل ترافیک و بینش جست‌وجو.",
    "rapid.overview": "نمای کلی",
    "rapid.traffic": "تحلیل ترافیک",
    "rapid.searchInsights": "بینش جست‌وجو",
    "rapid.governance": "حاکمیت",
    "rapid.billing": "صورت‌حساب",
    "rapid.hub": "هاب",
    "rapid.orgModel": "مدل سازمانی",
    "rapid.orgModelCopy": "سازمان‌ها باید APIها، اپلیکیشن‌ها، کاربران و تیم‌ها را در کنار ظرفیت صندلی و نقش‌ها مدیریت کنند.",
  },
  en: {
    "app.skip": "Skip to main content",
    "app.loadingRoute": "Loading route",
    "nav.home": "Home",
    "nav.browse": "API Hub",
    "nav.docs": "Docs",
    "nav.pricing": "Pricing",
    "nav.studio": "Studio",
    "nav.caller": "API Caller",
    "nav.consoleBadge": "API Console",
    "nav.tagline": "Discover, document, and manage APIs in one multilingual console",
    "nav.main": "Main navigation",
    "nav.mobile": "Mobile navigation",
    "nav.signIn": "Sign in",
    "nav.signUp": "Create account",
    "nav.dashboard": "Dashboard",
    "nav.logout": "Log out",
    "nav.openMenu": "Open menu",
    "nav.sheetDescription": "Fast access to console, docs, and account",
    "nav.workspace": "IranAPI Workspace",
    "nav.language": "Language",
    "footer.description": "A Persian and English API console for discovery, plan comparison, documentation, and access management from idea to stable integration.",
    "footer.quick": "Quick access",
    "footer.trust": "Trust and policies",
    "footer.terms": "Terms",
    "footer.privacy": "Privacy",
    "studio.title": "IranAPI Studio",
    "studio.metaDescription": "Create and manage API projects.",
    "studio.eyebrow": "API project workspace",
    "studio.subtitle": "Project operations, Hub listing prep, request testing, usage analytics, and API publishing in one workspace.",
    "studio.addProject": "Add API Project",
    "studio.newProject": "New API Project",
    "studio.projectName": "Project name",
    "studio.baseUrl": "Base URL",
    "studio.docsUrl": "Documentation URL",
    "studio.category": "Category",
    "studio.tags": "Tags: sms, webhook, ai",
    "studio.description": "Short project description",
    "studio.createPending": "Creating...",
    "studio.createPublish": "Create and Publish",
    "studio.search": "Search API Projects",
    "studio.all": "All",
    "studio.favorites": "Favorites",
    "studio.activeProjects": "active projects",
    "studio.emptyTitle": "You do not have any API Projects",
    "studio.emptyText": "Add a new API Project from scratch or use the Demo Project to explore publishing, docs, testing, and collaboration.",
    "studio.demoProject": "Demo Project",
    "studio.demoDescription": "Guided demo project with safe defaults.",
    "studio.updatedToday": "Updated today",
    "studio.checklist": "Studio launch checklist",
    "studio.tabProjects": "Projects",
    "studio.tabRequests": "Requests",
    "studio.tabTests": "Tests",
    "studio.tabListing": "Hub Listing",
    "studio.tabAnalytics": "Analytics",
    "studio.tabInbox": "Inbox",
    "studio.tabSettings": "Settings",
    "studio.requestsTitle": "Request console",
    "studio.testsTitle": "Tests and monitoring",
    "studio.listingTitle": "Hub listing readiness",
    "studio.analyticsTitle": "Usage analytics",
    "studio.inboxTitle": "Messages and discussions",
    "studio.settingsTitle": "Project settings",
    "studio.requestsCopy": "Keep method, path, headers, and sample body beside each IranAPI project, inspired by RapidAPI Client.",
    "studio.testsCopy": "Run health, latency, and publication checks before public display.",
    "studio.listingCopy": "Complete title, category, tags, docs, plans, and sample snippets for the Hub page.",
    "studio.analyticsCopy": "Track views, requests, active keys, and plan status in one operations view.",
    "studio.inboxCopy": "Follow consumer feedback, support requests, and documentation discussions.",
    "studio.settingsCopy": "Control auth, canonical version, support links, and publication state.",
    "studio.runTest": "Run test",
    "studio.publish": "Publish",
    "studio.configure": "Configure",
    "rapid.dashboardTitle": "IranAPI with RapidAPI-inspired Hub patterns",
    "rapid.dashboardCopy": "The IranAPI management view follows marketplace basics: overview, traffic analytics, and search term insights.",
    "rapid.overview": "Overview",
    "rapid.traffic": "Traffic analytics",
    "rapid.searchInsights": "Search insights",
    "rapid.governance": "Governance",
    "rapid.billing": "Billing",
    "rapid.hub": "Hub",
    "rapid.orgModel": "Organization model",
    "rapid.orgModelCopy": "Organizations manage APIs, applications, users, and teams beside seats and roles.",
  },
  ar: {
    "app.skip": "تخطي إلى المحتوى الرئيسي",
    "app.loadingRoute": "جاري تحميل المسار",
    "nav.home": "الرئيسية",
    "nav.browse": "مركز API",
    "nav.docs": "الوثائق",
    "nav.pricing": "الأسعار",
    "nav.studio": "الاستوديو",
    "nav.caller": "مستدعي API",
    "nav.consoleBadge": "وحدة تحكم API",
    "nav.tagline": "اكتشف ووثق وأدر واجهات API في لوحة متعددة اللغات",
    "nav.main": "التنقل الرئيسي",
    "nav.mobile": "تنقل الجوال",
    "nav.signIn": "تسجيل الدخول",
    "nav.signUp": "إنشاء حساب",
    "nav.dashboard": "لوحة التحكم",
    "nav.logout": "تسجيل الخروج",
    "nav.openMenu": "فتح القائمة",
    "nav.sheetDescription": "وصول سريع إلى اللوحة والوثائق والحساب",
    "nav.workspace": "مساحة عمل IranAPI",
    "nav.language": "اللغة",
    "footer.description": "لوحة API بالفارسية والإنجليزية للاكتشاف ومقارنة الخطط والوثائق وإدارة الوصول من الفكرة إلى التكامل المستقر.",
    "footer.quick": "روابط سريعة",
    "footer.trust": "الثقة والسياسات",
    "footer.terms": "الشروط",
    "footer.privacy": "الخصوصية",
    "studio.title": "استوديو IranAPI",
    "studio.metaDescription": "أنشئ وأدر مشاريع API.",
    "studio.eyebrow": "مساحة عمل مشروع API",
    "studio.subtitle": "عمليات المشروع، تجهيز صفحة المركز، اختبار الطلبات، تحليلات الاستخدام، ونشر API في مساحة واحدة.",
    "studio.addProject": "إضافة مشروع API",
    "studio.newProject": "مشروع API جديد",
    "studio.projectName": "اسم المشروع",
    "studio.baseUrl": "الرابط الأساسي",
    "studio.docsUrl": "رابط الوثائق",
    "studio.category": "الفئة",
    "studio.tags": "الوسوم: sms, webhook, ai",
    "studio.description": "وصف قصير للمشروع",
    "studio.createPending": "جاري الإنشاء...",
    "studio.createPublish": "إنشاء ونشر",
    "studio.search": "البحث في مشاريع API",
    "studio.all": "الكل",
    "studio.favorites": "المفضلة",
    "studio.activeProjects": "مشاريع نشطة",
    "studio.emptyTitle": "لا توجد لديك مشاريع API",
    "studio.emptyText": "أضف مشروع API جديدا أو استخدم المشروع التجريبي لاستكشاف النشر والوثائق والاختبار والتعاون.",
    "studio.demoProject": "مشروع تجريبي",
    "studio.demoDescription": "مشروع تجريبي موجه بإعدادات آمنة.",
    "studio.updatedToday": "تم التحديث اليوم",
    "studio.checklist": "قائمة إطلاق الاستوديو",
    "studio.tabProjects": "المشاريع",
    "studio.tabRequests": "الطلبات",
    "studio.tabTests": "الاختبارات",
    "studio.tabListing": "صفحة المركز",
    "studio.tabAnalytics": "التحليلات",
    "studio.tabInbox": "البريد",
    "studio.tabSettings": "الإعدادات",
    "studio.requestsTitle": "وحدة الطلبات",
    "studio.testsTitle": "الاختبارات والمراقبة",
    "studio.listingTitle": "جاهزية صفحة المركز",
    "studio.analyticsTitle": "تحليلات الاستخدام",
    "studio.inboxTitle": "الرسائل والنقاشات",
    "studio.settingsTitle": "إعدادات المشروع",
    "studio.requestsCopy": "احتفظ بالطريقة والمسار والترويسات ونموذج الجسم بجانب كل مشروع IranAPI، بإلهام من RapidAPI Client.",
    "studio.testsCopy": "شغل فحوصات الصحة والزمن وحالة النشر قبل العرض العام.",
    "studio.listingCopy": "أكمل العنوان والفئة والوسوم والوثائق والخطط ونماذج الشيفرة لصفحة المركز.",
    "studio.analyticsCopy": "تابع المشاهدات والطلبات والمفاتيح النشطة وحالة الخطط في عرض تشغيلي واحد.",
    "studio.inboxCopy": "تابع ملاحظات المستهلكين وطلبات الدعم ونقاشات الوثائق.",
    "studio.settingsCopy": "تحكم بالمصادقة والإصدار canonical وروابط الدعم وحالة النشر.",
    "studio.runTest": "تشغيل اختبار",
    "studio.publish": "نشر",
    "studio.configure": "إعداد",
    "rapid.dashboardTitle": "IranAPI بأنماط Hub مستوحاة من RapidAPI",
    "rapid.dashboardCopy": "يتبع عرض إدارة IranAPI أساسيات السوق: النظرة العامة، تحليلات المرور، ورؤى مصطلحات البحث.",
    "rapid.overview": "نظرة عامة",
    "rapid.traffic": "تحليلات المرور",
    "rapid.searchInsights": "رؤى البحث",
    "rapid.governance": "الحوكمة",
    "rapid.billing": "الفوترة",
    "rapid.hub": "المركز",
    "rapid.orgModel": "نموذج المؤسسة",
    "rapid.orgModelCopy": "تدير المؤسسات واجهات API والتطبيقات والمستخدمين والفرق إلى جانب المقاعد والأدوار.",
  },
};

const translations: Record<Locale, Record<TranslationKey, string>> = {
  ...baseTranslations,
  es: {
    ...baseTranslations.en,
    "app.skip": "Saltar al contenido principal",
    "app.loadingRoute": "Cargando ruta",
    "nav.home": "Inicio",
    "nav.browse": "Hub de API",
    "nav.docs": "Docs",
    "nav.pricing": "Precios",
    "nav.studio": "Studio",
    "nav.consoleBadge": "Consola API",
    "nav.tagline": "Descubre, documenta y gestiona APIs en una consola multilingue",
    "nav.main": "Navegacion principal",
    "nav.mobile": "Navegacion movil",
    "nav.signIn": "Iniciar sesion",
    "nav.signUp": "Crear cuenta",
    "nav.dashboard": "Panel",
    "nav.logout": "Cerrar sesion",
    "nav.openMenu": "Abrir menu",
    "nav.sheetDescription": "Acceso rapido a consola, docs y cuenta",
    "nav.workspace": "Espacio IranAPI",
    "nav.language": "Idioma",
    "footer.quick": "Acceso rapido",
    "footer.trust": "Confianza y politicas",
    "footer.terms": "Terminos",
    "footer.privacy": "Privacidad",
  },
  fr: {
    ...baseTranslations.en,
    "app.skip": "Aller au contenu principal",
    "app.loadingRoute": "Chargement de la page",
    "nav.home": "Accueil",
    "nav.browse": "Hub API",
    "nav.docs": "Docs",
    "nav.pricing": "Tarifs",
    "nav.studio": "Studio",
    "nav.consoleBadge": "Console API",
    "nav.tagline": "Decouvrez, documentez et gerez les API dans une console multilingue",
    "nav.main": "Navigation principale",
    "nav.mobile": "Navigation mobile",
    "nav.signIn": "Connexion",
    "nav.signUp": "Creer un compte",
    "nav.dashboard": "Tableau de bord",
    "nav.logout": "Deconnexion",
    "nav.openMenu": "Ouvrir le menu",
    "nav.sheetDescription": "Acces rapide a la console, aux docs et au compte",
    "nav.workspace": "Espace IranAPI",
    "nav.language": "Langue",
    "footer.quick": "Acces rapide",
    "footer.trust": "Confiance et politiques",
    "footer.terms": "Conditions",
    "footer.privacy": "Confidentialite",
  },
  tr: {
    ...baseTranslations.en,
    "app.skip": "Ana icerige gec",
    "app.loadingRoute": "Rota yukleniyor",
    "nav.home": "Ana sayfa",
    "nav.browse": "API Hub",
    "nav.docs": "Belgeler",
    "nav.pricing": "Fiyatlar",
    "nav.studio": "Studio",
    "nav.consoleBadge": "API Konsolu",
    "nav.tagline": "API'leri cok dilli tek konsolda kesfet, belgele ve yonet",
    "nav.main": "Ana gezinme",
    "nav.mobile": "Mobil gezinme",
    "nav.signIn": "Giris yap",
    "nav.signUp": "Hesap olustur",
    "nav.dashboard": "Panel",
    "nav.logout": "Cikis yap",
    "nav.openMenu": "Menuyu ac",
    "nav.sheetDescription": "Konsola, belgelere ve hesaba hizli erisim",
    "nav.workspace": "IranAPI Calisma Alani",
    "nav.language": "Dil",
    "footer.quick": "Hizli erisim",
    "footer.trust": "Guven ve politikalar",
    "footer.terms": "Kosullar",
    "footer.privacy": "Gizlilik",
  },
};

interface I18nContextValue {
  locale: Locale;
  dir: "rtl" | "ltr";
  setLocale: (locale: Locale) => void;
  toggleLocale: () => void;
  t: (key: TranslationKey) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const stored = window.localStorage.getItem("iranapi-locale");
    return isLocale(stored) ? stored : "fa";
  });

  const setLocale = (nextLocale: Locale) => {
    setLocaleState(nextLocale);
    window.localStorage.setItem("iranapi-locale", nextLocale);
  };

  useEffect(() => {
    const meta = getLocaleMeta(locale);
    document.documentElement.lang = meta.htmlLang;
    document.documentElement.dir = meta.dir;
  }, [locale]);

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      dir: getLocaleMeta(locale).dir,
      setLocale,
      toggleLocale: () => {
        const currentIndex = supportedLocales.findIndex((item) => item.code === locale);
        const nextLocale = supportedLocales[(currentIndex + 1) % supportedLocales.length]?.code || "fa";
        setLocale(nextLocale);
      },
      t: (key) => translations[locale][key],
    }),
    [locale],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const value = useContext(I18nContext);
  if (!value) {
    throw new Error("useI18n must be used inside I18nProvider");
  }
  return value;
}
