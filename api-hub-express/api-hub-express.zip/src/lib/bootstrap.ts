import type { API, APISummary, Category, Documentation, PaginatedResponse, PricingPlan } from "@/lib/api";

interface HomeBootstrap {
  categories: PaginatedResponse<Category>;
  featuredApis: PaginatedResponse<APISummary>;
  apis: PaginatedResponse<APISummary>;
}

interface BrowseBootstrap {
  categories: PaginatedResponse<Category>;
  recommendedApis: PaginatedResponse<APISummary>;
  apis: PaginatedResponse<APISummary>;
}

interface PricingBootstrap {
  pricingPlans: PaginatedResponse<PricingPlan>;
  apis: PaginatedResponse<APISummary>;
}

interface DocumentationBootstrap {
  apis: PaginatedResponse<APISummary>;
  documentations: PaginatedResponse<Documentation>;
}

interface ApiDetailBootstrap {
  api: API;
  similarApis: APISummary[];
}

interface FrontendBootstrapPayload {
  path?: string;
  home?: HomeBootstrap;
  browse?: BrowseBootstrap;
  pricing?: PricingBootstrap;
  documentation?: DocumentationBootstrap;
  apiDetail?: ApiDetailBootstrap;
}

let bootstrapCache: FrontendBootstrapPayload | null | undefined;

function readBootstrap() {
  if (bootstrapCache !== undefined) {
    return bootstrapCache;
  }

  if (typeof document === "undefined") {
    bootstrapCache = null;
    return bootstrapCache;
  }

  const element = document.getElementById("iranapi-bootstrap-data");
  const raw = element?.textContent?.trim();

  if (!raw) {
    bootstrapCache = null;
    return bootstrapCache;
  }

  try {
    bootstrapCache = JSON.parse(raw) as FrontendBootstrapPayload;
  } catch {
    bootstrapCache = null;
  }

  return bootstrapCache;
}

export function getHomeBootstrap() {
  return readBootstrap()?.home ?? null;
}

export function getBrowseBootstrap() {
  return readBootstrap()?.browse ?? null;
}

export function getPricingBootstrap() {
  return readBootstrap()?.pricing ?? null;
}

export function getDocumentationBootstrap() {
  return readBootstrap()?.documentation ?? null;
}

export function getApiDetailBootstrap() {
  return readBootstrap()?.apiDetail ?? null;
}
